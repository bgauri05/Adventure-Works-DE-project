/*
============================================================

LEGACY IMPLEMENTATION

This script follows the original YouTube tutorial.

The tutorial creates:
- Database Scoped Credential
- External Data Source
- External File Format
- External Tables (CETAS)

These commands were not compatible with the
Azure Synapse Serverless SQL environment
used in this project.

Instead, the project uses OPENROWSET and
SQL Views over Parquet files stored in ADLS Gen2.

This approach is simpler, serverless,
and avoids unnecessary data duplication.

============================================================
*/

CREATE DATABASE SCOPED CREDENTIAL cred_gauri
WITH
IDENTITY = 'Managed Identity';

create external data source source_silver
WITH
(
    LOCATION = 'https://awstoragegauri119.blob.core.windows.net/silver' ,
    CREDENTIAL = cred_gauri
)

create external data source source_gold
WITH
(
    LOCATION = 'https://awstoragegauri119.blob.core.windows.net/gold' ,
    CREDENTIAL = cred_gauri
)

SELECT *
FROM sys.external_data_sources;

CREATE EXTERNAL FILE FORMAT FORMAT_PARQUET
WITH
(
    FORMAT_TYPE = PARQUET
);


SELECT *
FROM sys.external_file_formats;


SELECT TOP 10 *
FROM OPENROWSET(
    BULK 'AdventureWorks_Sales/',
    DATA_SOURCE = 'source_silver',
    FORMAT = 'PARQUET'
) AS sales;

CREATE OR ALTER VIEW gold.sales
AS

SELECT *

FROM OPENROWSET(

    BULK 'AdventureWorks_Sales/',

    DATA_SOURCE = 'source_silver',

    FORMAT='PARQUET'

) AS sales;


SELECT *
FROM sys.database_scoped_credentials;

